package pe.edu.universidad.dao;

import java.sql.Connection; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import pe.edu.universidad.entidades.Curso;


public class DaoMatricula extends DaoGenerico {

	public List<Curso> consultarCursosPorUsuario(int idUsuario) {
		List<Curso> lst = new ArrayList<Curso>();
		String sql = "SELECT c.id, c.nombre	FROM matriculas m inner join cursos c on c.id=m.idcurso inner join usuarios u on u.id=m.idusuario where u.id=?";
		Connection cnx = getConnection();
		ResultSet rs;
		try {
			PreparedStatement stm = cnx.prepareStatement(sql);
			stm.setInt(1, idUsuario);
			rs = stm.executeQuery();
			while (rs.next()) {
				Curso c = new Curso();
				c.setId(rs.getInt(1));
				c.setNombre(rs.getString(2));
				lst.add(c);
			}
			cnx.close();
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
		return lst;
	}
	
}
